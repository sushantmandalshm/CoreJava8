package com.capgemini.bank.service;

import java.sql.SQLException;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;

class NameValidException extends Exception
{
	String s;
	NameValidException(String s) //User defined exception for name validation
	{ 
		this.s=s;
	}
	public String toString()
	{
		return s+" is not a valid name. Only Alphabets are allowed";
	}
	
}

class CapgePhoneException extends Exception //User defined exception for phone number validation
{    
	String s;
	CapgePhoneException(String s){
		this.s=s;
	}
	public String toString(){
		return s+" is not a valid phone number. Only 10 numeric digits are allowed)";
	}
}
class CapgeDamtException extends Exception //User defined exception for Demand draft validation
{    
	double d;
	CapgeDamtException(double d)
	{
		this.d=d;
	}
	public String toString(){
		return d+" Amount  entered is not proper. Amounts till 5,00,000 allowed. Only numeric values are accepted";
	}
}

public class DemandDraftService implements IDemandDraftService 
{

	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException 
	{
		int flag=1;  
		Double ddcomm = 0.0;
		if(demandDraft.getDdamt()<=5000){
			ddcomm=10.0;
		}
		else if(demandDraft.getDdamt()>5000 && demandDraft.getDdamt()<=10000){
			ddcomm=41.0;
		}
		else if(demandDraft.getDdamt()>10000 && demandDraft.getDdamt()<=100000){
			ddcomm=51.0;
		}
		else if(demandDraft.getDdamt()>100000 && demandDraft.getDdamt()<=500000){
			ddcomm=306.0;
		}
		demandDraft.setComm(ddcomm);
		
		try{
		if(!demandDraft.getPhonenum().matches("[0-9]{10}")){
			throw new CapgePhoneException(demandDraft.getPhonenum());
		}
		}
		catch(CapgePhoneException e){
			flag=0;
			e.printStackTrace();
		}
		try{
			if(!demandDraft.getDdamt().toString().matches("[0-9.]+") || (demandDraft.getDdamt()>500000) )
				{
				throw new CapgeDamtException(demandDraft.getDdamt());
				}
			}
		catch(CapgeDamtException e)
			{
			flag=0;
			e.printStackTrace();
			}
		try{
			if(!demandDraft.getCustname().matches("[a-z A-Z]+"))
				{
				throw new NameValidException(demandDraft.getCustname());
				}
			}
		catch(NameValidException e)
			{
				flag=0;
				e.printStackTrace();
			}

		if(flag==1)
		{
			DemandDraftDAO ddd= new DemandDraftDAO();
			ddd.addDemandDraftDetails(demandDraft); //Calling method from DataDemandDOA to add data to our table
		}
		return flag;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) 
	{	
		return null;
	}

}
