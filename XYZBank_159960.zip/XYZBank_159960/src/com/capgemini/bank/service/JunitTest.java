package com.capgemini.bank.service;
import static org.junit.Assert.*;

import java.sql.SQLException;

import  org.junit.Test;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;

public class JunitTest 
{

	@Test
	public void testAddDemandDraftDetails() throws SQLException{
		DemandDraft demandDraft = new DemandDraft();
		demandDraft.setCustname("John");
		demandDraft.setPhonenum("9768587350");
		demandDraft.setIfvr("Capgemini");
		demandDraft.setDdamt(45000.0);  
		demandDraft.setDesc("DD taken in favor of Capgemini");
		demandDraft.setComm(300.0);    
		DemandDraftService test = new DemandDraftService();
		assertEquals(1, test.addDemandDraftDetails(demandDraft));   //if succesful will return 1
	}
}