package com.capgemini.bank.dao;

import java.sql.DriverManager;


import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;

public class DemandDraftDAO implements IDemandDraftDAO {
	static Logger Log=Logger.getLogger(DemandDraftDAO.class.getName());
	
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft){
		Date d = new Date();
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		}
		catch(ClassNotFoundException e){
			e.printStackTrace();
		}
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		String user="hr";
		String pass="hr";
	
		Connection con=null;
		try {
			con = DriverManager.getConnection(url,user,pass);
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		Log.info("Connection created");

		String sql="insert into demand_draft values(?,?,?,?,?,?,?,?)";
		
		/*(1)transaction_id NUMBER,(2)customer_name VARCHAR2(20),
		 * (3)in_favor_of  VARCHAR2(20), 
		(4)phone_number VARCHAR2(10),(5) date_of_transaction DATE,
		(6) dd_amount NUMBER, 
		(7)dd_commission NUMBER, 
		(8)dd_description VARCHAR2(50)*/
		
		
		
		Statement stat=null;
		try {
			stat = con.createStatement();
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		Log.info("Created statement to execute sequence query separately");
		ResultSet rst=null;
		try {
			rst = stat.executeQuery("select Transaction_id_Seq.nextval from dual");
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		Log.info("Executing Transaction_id_Seq.nextval and storing it");
		try {
			while(rst.next()){
			demandDraft.setTid(Integer.valueOf(rst.getInt(1)));
			}
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		PreparedStatement ps=null;
		try {
			ps = con.prepareStatement(sql);
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		
		try {
			ps.setInt(1,demandDraft.getTid());
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		Log.info("Transaction id is set");
		try {
			ps.setString(2,demandDraft.getCustname());
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		Log.info("Customer name is set");
		try {
			ps.setString(3, demandDraft.getIfvr());
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		Log.info("In favour of is set");
		try {
			ps.setString(4, demandDraft.getPhonenum());
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		Log.info("Phone number is set");
		try {
			ps.setDate(5, new java.sql.Date(d.getTime()));
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		Log.info("Transaction date is set");
		try {
			ps.setDouble(6, demandDraft.getDdamt());
		} catch (SQLException e) {
			 
			e.printStackTrace();
		}
		Log.info("DD amount is set");
		try {
			ps.setDouble(7,demandDraft.getComm());
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		Log.info("DD commission is set");
		try {
			ps.setString(8, demandDraft.getDesc());
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		Log.info("DD description is set");
		try {
			ps.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		Log.info("Values in 1 row is inserted");
		try {
			con.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		Log.info("Connection closed");
		return 1;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		
		return null;
	}
	

}
