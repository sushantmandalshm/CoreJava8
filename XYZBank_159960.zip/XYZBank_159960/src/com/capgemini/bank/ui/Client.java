package com.capgemini.bank.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;

//Banking Application to enter customer provided demand draft details 

public class Client 
{
	
	static Logger Log=Logger.getLogger(Client.class.getName());
	
	public static void main(String...a) throws NumberFormatException, IOException
	{
		Integer operation;
		
		
		BufferedReader bfr= new BufferedReader(new InputStreamReader(System.in)); //Accepting User Input

		
		System.out.println("Enter Operation Type:\n1)Enter Demand Draft Details\n2)Exit"); //Display Menu
		operation= Integer.parseInt(bfr.readLine());
		switch(operation){
		case 1:
			DemandDraft dd1= new DemandDraft();
			System.out.print("Enter the name of the customer: ");
			dd1.setCustname(bfr.readLine());
			System.out.print("Enter customer phone number: ");
			dd1.setPhonenum(bfr.readLine());
			System.out.print("In favour of: ");
			dd1.setIfvr(bfr.readLine());
			System.out.print("Enter Demand Draft amount (in Rs): ");
			dd1.setDdamt(Double.parseDouble(bfr.readLine()));
			System.out.print("Enter Remarks: ");
			dd1.setDesc(bfr.readLine());
			DemandDraftService ds=new DemandDraftService();
			try 
			{
				if(ds.addDemandDraftDetails(dd1)==0)
				{
					System.out.println("Exceptions errors");
					System.out.println("Demand Draft Application closing***\n closed**");
					System.exit(0);
				}
			} catch (SQLException e) 
			{
				e.printStackTrace();
			}
			//System.out.println("Your Demand Draft request has been successfully registered along with the "+dd1.getTid());
			Log.info("Your Demand Draft request has been successfully registered along with the "+dd1.getTid());
			break;
		case 2:
			bfr.close();
			System.out.println("***Demand Draft Application Closed***\n***Thank You!!!***");
			break;
		default:
			bfr.close();
			System.out.println("***Invalid Operation***\n***Demand Draft Application Closed***\n***Thank You!!!**");
		}
	}
}
