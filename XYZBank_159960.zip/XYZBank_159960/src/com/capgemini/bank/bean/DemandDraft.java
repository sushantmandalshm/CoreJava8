package com.capgemini.bank.bean;

//Creating Bean Class with required properties 

public class DemandDraft {
	String custname;
	String phonenum;
	String ifvr;
	Double ddamt;
	String desc;
	Double comm;
	Integer tid;
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public String getPhonenum() {
		return phonenum;
	}
	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}
	public String getIfvr() {
		return ifvr;
	}
	public void setIfvr(String ifvr) {
		this.ifvr = ifvr;
	}
	public Double getDdamt() {
		return ddamt;
	}
	public void setDdamt(Double ddamt) {
		this.ddamt = ddamt;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public Double getComm() {
		return comm;
	}
	public void setComm(Double comm) {
		this.comm = comm;
	}
	public Integer getTid() {
		return tid;
	}
	public void setTid(Integer tid) {
		this.tid = tid;
	}


	
}
