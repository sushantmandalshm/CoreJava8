package com.cucumber.CucumberTest;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = {"classpath:features/registration-form.feature"}
		,plugin = {"pretty","html:target/reports"}
		,glue = {"scr/main/webapp/pages/Register"}
		)
public class RegistrationIntegrationTest {

}
