package com.cg.JunitTest;

/**
 * Hello world!
 *
 */
public class App 
{
    public long add(int a,int b)
    {
       return (long)a+b;
    }
}
