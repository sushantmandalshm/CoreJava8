package com.cg.JunitTest;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest {
	/**
	 * Rigorous Test :-)
	 */

	@Before
	public void beforemethod() {
		System.out.println("Before method");
	}

	@Test(timeout = 10)
	public void shouldAnswerWithTrue() {
		for (int i = 0; i < 100; i++) {
			System.out.println(i);
		}
	}

	@After
	public void aftermethod() {
		System.out.println("After method");
	}
}
