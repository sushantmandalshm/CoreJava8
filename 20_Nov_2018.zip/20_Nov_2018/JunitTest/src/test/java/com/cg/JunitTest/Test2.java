package com.cg.JunitTest;

import java.util.Scanner;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class Test2 {
	
	int a;
	@Before
	public void inita()
	{
		Scanner sc = new Scanner(System.in);
		a=sc.nextInt();
		sc.close();
	}
	
	@Test
		public void tested()
		{	
			if(a==1)
			Assert.assertEquals(new com.cg.JunitTest.App().add(1, 2),3);
			else
			Assert.fail();
			
		}
	
	@After
	public void destroy()
	{
		System.out.println("Testing done...");
	}
}
