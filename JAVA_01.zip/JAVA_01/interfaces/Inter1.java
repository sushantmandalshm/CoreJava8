package com.capgemini.interfaces;

interface Inter
{	
			   int a=90;
	/*public*/ void inters();
}
public interface Inter1 extends Inter {
	/*public*/ void interdisplay();
}
