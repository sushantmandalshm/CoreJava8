package com.capgemini.Core;

public class FunctionOverlad {

	public void readme() {
		System.out.println("redme void public");
	}

	int readme(Float a, int b, Integer c[]) {
		System.out.println("redme void3  private");
		return 3;
	}
	protected int readme(int b,int... a) {
		System.out.println("redme var args private");
		return a.length;
	}

	private int readme(int a,int b) {
		System.out.println("lets move ");
		return 2;
	}

	public static void main(String... a) {
		FunctionOverlad ob = new FunctionOverlad();
		System.out.println(ob.readme(new Integer(2),
				new Integer(3),new Integer(4)));
	}
}