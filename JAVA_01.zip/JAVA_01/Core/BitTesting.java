package com.capgemini.Core;

public class BitTesting {

	public static void main(String[] args) {
		System.out.println(2|3);
		System.out.println(2&3);
		System.out.println(2<3);
		System.out.println(2.30f == 2.30);
		System.out.println(true==true);
		System.out.println('2'==2);
		Double f=new Double(2.134355454545);
		System.out.println(f.byteValue());
	}

}
