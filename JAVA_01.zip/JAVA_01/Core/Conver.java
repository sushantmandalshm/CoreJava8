package com.capgemini.Core;

public class Conver {
	
	int x = 50;
	String z = "apple";
	String l;
	Conver(){
		l=x+z;
	}
	public String toString()
	{
		return l;
	}
	public static void main(String[] args) {
		//Integer
		int a=90;
		Integer b=900; //wrapper class
		Integer obj = new Integer(a);
		String s1 = obj.toString();
		System.out.println("The string is: "+s1);
		System.out.println(b.toString());
		//float
		float c = 2.53f;
		Float d = 2.53f;
		Float obj1 = new Float(c);
		String s2 = obj1.toString();
		System.out.println("The float is: "+s2);
		System.out.println(d.toString());
		// double
		double e = 2.55;
		Double f = 2.55;
		Double obj2 = new Double(e);
		String s3 = obj2.toString();
		System.out.println("The double is: "+s3);
		System.out.println(f.toString());
		//object
		Conver obj3 = new Conver();
		System.out.println(obj3.toString());
	}
}
