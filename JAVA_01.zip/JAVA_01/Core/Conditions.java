public class Conditions
{
	public static void main(String...a)
	{
		int z=50;
		if(z<10)
		{
			System.out.println(z+" is a small number.");
		}
		else if(z>=10 && z<=50)
		{
			System.out.println(z+" is a medium number.");
		}
		else
		{
			System.out.println(z+" is a large number.");
		}
	}
}