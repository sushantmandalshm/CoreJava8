import java.util.Scanner;
public class Add
{
	public static void main(String...z)
	{	
		//String a,b;
		/*int a,b;
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the 1st number: ");
		a = s.nextInt();
		System.out.println("Enter the 2nd number: ");
		b=s.nextInt();
		System.out.println("The sum is: "+(a+b));
		//System.out.println(a+b);*/
		/*Scanner s = new Scanner(System.in);
		System.out.println("Enter the first string: ");
		a=s.next();
		System.out.println("Enter the second string: ");
		b=s.next();
		System.out.println("The emtered strings are: "+(a+","+b));*/
	}
}