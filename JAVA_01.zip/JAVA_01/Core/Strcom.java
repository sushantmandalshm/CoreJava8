public class Strcom
{
	public static void main(String...z)
	{
		String s1 = new String("Hello");
		String s2 = new String("Hello");
		String s3 = new String("Hi");
		/*String s1 = "Hello";
		String s2 = "Hello";
		String s3 = "Hi";*/
		//System.out.println(s1);
		//System.out.println(s2);
		System.out.println(s1==s2);
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(s3));
		System.out.println(s1.charAt(0));
		System.out.println(s2.length());
		System.out.println(s2.toUpperCase());
		System.out.println(s1.toLowerCase());
		System.out.println(s1);
	}
}