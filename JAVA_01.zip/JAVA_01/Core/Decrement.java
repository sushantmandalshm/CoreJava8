public class Decrement
{
	public static void main(String...a)
	{
		int z=1000;
		while(z>=0)
		{
			System.out.print(z+" ");
			//System.out.println(z);
			z-=10;
		}
	}
}