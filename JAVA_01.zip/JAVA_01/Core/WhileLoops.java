public class WhileLoops
{
	public static void main(String...a)
	{
		int i=0;
		while(i<=50)
		{
			System.out.println(i);
			i++;
		}
	}
}