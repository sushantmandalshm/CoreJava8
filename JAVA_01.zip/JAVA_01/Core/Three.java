public class Three
{
	public static void main(String...z)
	{
		byte a = 135;
		byte b = -1;
		System.out.println(a+b);
	
	}
}