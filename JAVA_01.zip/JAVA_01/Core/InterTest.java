package com.capgemini.Core;

import com.capgemini.interfaces.Inter1;

public class InterTest implements Inter1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InterTest imp = new InterTest();
		imp.inters();
	}

	@Override
	public void inters() {
		// TODO Auto-generated method stub
		System.out.println("inters"+Inter1.a);
	}

	@Override
	public void interdisplay() {
		// TODO Auto-generated method stub
		System.out.println("interdisplay");
		
	}

}
