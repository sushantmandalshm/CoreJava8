public class CaseExamp
{
	public static void main(String...a)
	{
		String z="ABC";
		/*switch(z)
		{
			case 'A': 
			case 'a':
				System.out.println("You entered A or a");
				break;
			case 'B':
				System.out.println("You entered B");
				break;
			default:
				System.out.println("You didn't enter either A or B");
		}*/
		switch(z)
		{
			case "ABC": 
				System.out.println("You entered ABC");
				break;
			case "DEF":
				System.out.println("You entered DEF");
				break;
			default:
				System.out.println("You didn't enter either ABC or DEF");
		}
	}
}