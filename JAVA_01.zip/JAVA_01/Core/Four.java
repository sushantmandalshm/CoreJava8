public class Four
{
	public static void main(String...z)
	{
	int a = 2;
	int b = 3;
	a = a + (b*3) + (5*6) + (a+b);
	System.out.println(a);
	}
}