package com.capgemini.Core;

public class ThisExamp 
	{
		int a,b;
		public void setData(int a, int b)
		{
			a=a;
			b=b;
		}
	public void showData()
	{
			System.out.println("Value of A ="+a);
			System.out.println("Value of B ="+b);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			ThisExamp obj = new ThisExamp();
			obj.setData(2,3);
			obj.showData();
	}

}
