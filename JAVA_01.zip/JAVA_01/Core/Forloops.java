public class Forloops
{
	public static void main(String...z)
	{
		int i;
		for(i=1;i<=10;i++)
		{
			System.out.println("2"+"x"+i+"="+(2*i));
		}
	
	}

}