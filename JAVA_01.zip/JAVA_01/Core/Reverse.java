public class Reverse
{
	public static void main(String...z)
	{
		for(int i=90;i>=65;i--)
		{
			System.out.println((char)i);
		}
	
	}
}