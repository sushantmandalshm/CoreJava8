class BaseClass
{
	public void callme()
	{
		System.out.println("Base");
	}
}
public class Dog
{
	private boolean live=true;
		private void bark()
		{
			if(live)
			System.out.println("Bowh Bowh");
		}
			public static void main(String...a)
			{
				Dog zo=new Dog();
				zo.bark();
				BaseClass bb = new BaseClass();
				bb.callme();
				System.out.println(zo);
				System.out.println(bb.hashCode());
			}
}