package com.capgemini.Core;

public class OverLoading 
{
	public void readme()
	{
			System.out.println("Void Readme");
	}
	int readme(int a,int b, int c[])
	{
		System.out.println("Int Readme");
		return 3;
	}
	protected int readme(Integer...a)
	{
		System.out.println("Int Readme protected");
		return 3;
	}
	private int readme(int a, int b)
	{
			System.out.println("Private Readme");
			return 2;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OverLoading ob = new OverLoading();
		System.out.println(ob.readme(new Integer(2),new Integer(3),
				new Integer(4)));
	}

}
