class IncreDecre
{
	public static void main(String...z)
	{
		int a,b,c;
		a = 10;
		b = a++;//output:10
		c = ++a;
		System.out.println(b);
	}
}