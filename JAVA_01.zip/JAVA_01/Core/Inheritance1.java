package com.capgemini.Core;

class A
{
	protected void display()
	{
		System.out.println("a.display");
	}
}

public class Inheritance1 extends A {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Inheritance1 op =new Inheritance1();
		op.display();
	}

}
