package com.capgemini.Core;

public class Datatypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 10;
		int y = 20;
		float z;
		char a = 'A';
		String b = "Apple";
		z = (float)x / y;
		System.out.println(z);
		System.out.println(a);
		System.out.println(b);
	}

}
