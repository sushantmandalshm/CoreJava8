public class TestCases
{
	public static void main(String...z)
	{
		int a = 123;
		char b = 'c';
		System.out.println(a+b); //output:222
		System.out.println('c'+'d'); //output:199
		System.out.println('c'+""+'d'); //output:cd
		System.out.println("c"+"d"); //output:cd
		System.out.println("cd"+'d'); //output:cdd
		System.out.println("cd"+1); //output:cd1
		System.out.println('c'+1); //output:100
	}
}