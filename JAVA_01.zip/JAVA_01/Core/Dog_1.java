class BaseClass
{
	public static void callme()
	{
		System.out.println("Base");
		System.out.println(Dog_1.live);
	}
}
class Hello
{
	public static void user()
	{
		System.out.println("Hello User!!!");
	}
}
public class Dog_1
{
	public static boolean live=true;
		public void bark()
		{
			if(live)
			System.out.println("Bowh Bowh");
		}
			public static void main(String...a)
			{
				Dog_1 zo=new Dog_1();
				zo.bark();
				//BaseClass bb = new BaseClass();
				//bb.callme();
				BaseClass.callme();
				Hello.user();
			}
}