package com.capgemini.Core;
import java.time.LocalDate;
import java.util.Date;
public class DateExamp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date date = new Date();
		LocalDate today = LocalDate.now();
		System.out.println(date);
		System.out.println(today);
	}

}