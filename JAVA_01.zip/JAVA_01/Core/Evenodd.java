public class Evenodd
{
	public static void main(String...z)
	{
		for(int i=0;i<=100;i++)
		{
			if(i%2==0)
			{
				System.out.println(i+" is even");
			}
			else
			{
			System.out.println(i+" is odd");
			}
		}
	}
}