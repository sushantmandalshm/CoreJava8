public class IntArray
{
	public static void main(String...z)
	{
		/*int arr[];
		arr = new int[5];
		arr[0] = 65;
		arr[1] = 66;
		arr[2] = 67;
	    arr[3] = 68; 
		arr[4] = 69;
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("Element at index "+i+" is: "+arr[i]);
		}*/
		//String apple[]={"banana","mango","papaya"};
		String[] apple={"banana","mango","papaya"};
		String arr[];
		arr = new String[5];
		arr[0] = "ABC";
		arr[1] = "DEF";
		arr[2] = "GHIJ";
	    arr[3] = "KLMNOPQRST"; 
		arr[4] = "UVWXYZ";
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("Element at index "+i+" is: "+arr[i]);
		}
			System.out.println(apple[0]);
	}	
}