package com.capgemini.Core;
import java.util.Scanner;
public class Input {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a float: ");
		float number = input.nextFloat();
		System.out.println("You entered " + number);
	}

}
