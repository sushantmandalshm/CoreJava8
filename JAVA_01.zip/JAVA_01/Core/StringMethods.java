package com.capgemini.Core;

public class StringMethods {
	static String aString = "Capgemini";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        StringBuffer s=new StringBuffer(aString); 
        //int p=s.length(); 
        //int q=s.capacity();
        System.out.println(s.length());
        System.out.println(s.capacity());
        System.out.println(s.append("Hyd"));
        System.out.println(s.charAt(3));
        System.out.println(s.reverse());
        System.out.println(s.insert(5,"Lenovo"));
        //System.out.println("Length of aString is "+p); 
        //System.out.println("Capacity of aString is "+q); 
	}

}
