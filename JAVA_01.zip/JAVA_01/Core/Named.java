public class Named
{	
	
	//int a;
	//a = 50;
	{
		System.out.println("Unnamed Block");
	}
	
	static 
	{
		System.out.println("Static Unamed Block");
	}
	
	public void callnonstatic()
	{
		System.out.println("Non Static Block");
	}
	
	public static void staticfunc()
	{
		System.out.println("Static Func");
	}
	
	public static void main(String a[])
	{
		Named obj=new Named();
		obj.callnonstatic();
		Named.staticfunc();
	}
}