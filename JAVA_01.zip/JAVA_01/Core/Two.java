public class Two
{
	public static void main(String...z)
	{
	byte a = 35;
	byte b = 44;
	byte c = a + b;
	//c = a + b;
	System.out.println(c);
	}
}