public class One
{
	public static void main(String...z)
	{
		byte a=35;
		byte b=44;
		//byte c=a+b;
		//System.out.println(c);
		System.out.println(a+b);
	}
}