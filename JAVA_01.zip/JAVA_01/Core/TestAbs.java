package com.capgemini.Core;

import com.capgemini.abstracts.AbsClass1;

public class TestAbs extends AbsClass1{
	
	public void callme()
	{
		System.out.println("Called from AbsClass1"+"display");
	}
	public static void main(String[] args){
		
		TestAbs abs=new TestAbs();
		abs.display();
		abs.callme();
	}
}
