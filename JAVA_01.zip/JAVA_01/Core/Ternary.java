public class Ternary
{
	public static void main(String...z)
	{
		int a = 5;
		int b = 6;
		String str_1,str_2,result;
		str_1 = "a is greater than b";
		str_2 = "b is greater than a";
		result = (a>b)?str_1:str_2;
		System.out.println(result);
	}
}