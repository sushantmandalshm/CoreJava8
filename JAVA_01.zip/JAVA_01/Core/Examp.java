class Examp
{
	public static void main(String...z)
	{
		String a = "Apple";
		a.concat("a");
		System.out.println(a);
	}
}