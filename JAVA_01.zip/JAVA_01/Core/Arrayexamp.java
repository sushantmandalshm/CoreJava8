import java.util.Scanner;
public class Arrayexamp
{
	public static void main(String b[])
	{
		int a[]=new int[5];
		a[0]=1;
		a[1]=2;
		a[2]=3;
		a[3]=4;
		a[4]=5;
		Scanner ss=new Scanner(System.in);
		System.out.println("Enter 4th array element: ");
		a[4]=ss.nextInt();
		for(int i=0;i<a.length;i++)
			System.out.println(a[i]);
	
	}
}