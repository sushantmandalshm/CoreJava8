package com.capgemini.abstracts;


abstract class Abs
{
	public abstract void display();
	public void callme()
	{
		System.out.println("Called from Abs callme");
	}
}

public class AbsClass1 extends Abs {
	public void display()
	{
		System.out.println("Called from AbsClass1 display");
	}
	public static void main(String[] args){
		
AbsClass1 abs=new AbsClass1();
abs.display();
abs.callme();
	}

}
