package com.capgemini.exceptions;

public class Except1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			int a[]=new int[4];
			for(int i=0;i<=5;i++)
				a[i] = 22 + i;
		}
		catch(Exception e)
		{
			//System.out.println(e.getCause().getMessage());
			e.printStackTrace();
		}
		/*catch(ArrayIndexOutofBoundsException e)
		{
			//System.out.println(e.getCause().getMessage());
			try:
			e.printStackTrace();
		}*/
	}

}
