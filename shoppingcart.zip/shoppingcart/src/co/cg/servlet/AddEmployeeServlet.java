package co.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AddEmployeeServlet extends HttpServlet 
{

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String name = request.getParameter("empname");
		String salary = request.getParameter("empsal");
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "hr";
			String pass = "hr";
			Connection con = DriverManager.getConnection(url,user,pass);
			String sql = "select eid_seq.nextval from dual";
			PreparedStatement ps = con.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			int id =0;
			if(rs.next())
			{
				id = rs.getInt(1);
			}
			sql = "insert into employee values(?,?,?)";
			ps= con.prepareStatement(sql);
			ps.setInt(1,id);
			ps.setString(2, name);
			ps.setDouble(3,Double.parseDouble(salary));
			int n = ps.executeUpdate();
			if(n>=1)
			{	
				out.println("<b style='color:green'>added successfully</b>");
				RequestDispatcher rd = request.getRequestDispatcher("addEmployee.jsp");
				rd.include(request, response);
			}
			else
			{
				out.println("<b style='color:red'>Something went wrong</b>");
				RequestDispatcher rd = request.getRequestDispatcher("addEmployee.jsp");
				rd.include(request, response);
			}
		}
		catch(Exception e)
		{
			out.println(e);
		}
	}

}
