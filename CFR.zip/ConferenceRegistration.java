package com.capgemini.selenium;

import java.sql.Driver;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;


public class ConferenceRegistration 
{	
	String baseUrl = "";
	WebDriver driver = null;
	
	@Before
	public void pre()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Topup\\chromedriver.exe");
		driver = new ChromeDriver();
		baseUrl = "http://localhost:9999//SeleniumWebTest//ConferenceRegistartion.html";
	}
	
	//@Given("^I am on the registration page$")
	@Test
	public void i_am_on_the_registration_page() 
	{
	    driver.get(baseUrl);
	    driver.findElement(By.linkText("Next")).click();

	}

	//@When("^I click on Next$")
	//@Test
	public void i_click_on_Next() 
	{
		//driver.findElement(By.linkText("Next")).click();
	}

	//@Then("^I get a message$")
	public void i_get_a_message() throws Throwable 
	{
	    // Write code here that turns the phrase above into concrete actions
	}

	//@Given("^I enter the first name$")
	public void i_enter_the_first_name() throws Throwable 
	{
	    // Write code here that turns the phrase above into concrete actions
	}

	//@Given("^I enter first name$")
	public void i_enter_first_name() throws Throwable 
	{
	    // Write code here that turns the phrase above into concrete actions
	}

	//@Given("^I enter second name$")
	public void i_enter_second_name() throws Throwable 
	{
	    // Write code here that turns the phrase above into concrete actions
	}

	//@Given("^I enter email$")
	public void i_enter_email() throws Throwable 
	{
	    // Write code here that turns the phrase above into concrete actions
	}

	//@Given("^I enter contact no$")
	public void i_enter_contact_no() throws Throwable 
	{
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	//@Given("^I enter the no of people$")
	public void i_enter_the_no_of_people() throws Throwable 
	{
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	//@Given("^I enter the building name$")
	public void i_enter_the_building_name() throws Throwable 
	{
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	//@Given("^I enter the area name$")
	public void i_enter_the_area_name() throws Throwable 
	{
	    // Write code here that turns the phrase above into concrete actions
	}

	//@Given("^I select the city$")
	public void i_select_the_city() throws Throwable 
	{
	    // Write code here that turns the phrase above into concrete actions
	}

	//@Given("^I select the state$")
	public void i_select_the_state() throws Throwable
	{
	    // Write code here that turns the phrase above into concrete actions

	}

	//@Given("^I select as a member$")
	public void i_select_as_a_member() throws Throwable 
	{
	    // Write code here that turns the phrase above into concrete actions
	}

	//@Given("^I select as a non member$")
	public void i_select_as_a_non_member() throws Throwable 
	{
	    // Write code here that turns the phrase above into concrete actions
	}
	
	@After
	public void post()
	{
		//driver.close();
	}
}
