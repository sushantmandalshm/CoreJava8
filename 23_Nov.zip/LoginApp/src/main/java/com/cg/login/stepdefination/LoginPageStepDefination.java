package com.cg.login.stepdefination;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.login.beans.LoginPageBean;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginPageStepDefination {

	private WebDriver driver;
	private LoginPageBean pageBean;

	@Before
	public void pre() {
		System.setProperty("webdriver.chrome.driver", "D:\\Selenium\\chromedriver.exe");
	}

	@Given("^User is on the login page$")
	public void user_is_on_the_login_page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("http://localhost:9999/LoginApp/login.html");
		driver.manage().window().maximize();
		pageBean = new LoginPageBean();
		PageFactory.initElements(driver, pageBean);

	}

	@When("^User clicks on 'Submit' without entering 'UserName'$")
	public void user_clicks_on_Submit_without_entering_UserName() throws Throwable {

		pageBean.submitbuttonclick();
	}

	@Then("^'Please fill Username' message should display$")
	public void please_fill_Username_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill Username";
		Assert.assertEquals(expectedMessage, actualMessage);

	}

	@When("^User clicks on 'Submit' without entering 'Password'$")
	public void user_clicks_on_Submit_without_entering_Password() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setName("SHM");
		Thread.sleep(5000);
		pageBean.submitbuttonclick();
	}

	@Then("^'Please fill the Password' message should display$")
	public void please_fill_the_Password_message_should_display() throws Throwable {

		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Please fill the Password";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User clicks 'Submit'$")
	public void user_clicks_Submit() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setPasswrd("123");
		Thread.sleep(5000);
		pageBean.submitbuttonclick();

	}

	@Then("^'Successfully Submitted!' message should display$")
	public void successfully_Submitted_message_should_display() throws Throwable {
		String actualMessage = driver.switchTo().alert().getText();
		String expectedMessage = "Successfully Submitted!";
		Assert.assertEquals(expectedMessage, actualMessage);

	}

}
