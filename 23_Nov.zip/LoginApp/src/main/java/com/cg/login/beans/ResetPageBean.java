package com.cg.login.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ResetPageBean {
	@FindBy(how = How.NAME, name = "reset")
	private WebElement resetb;
	
	public void resetbuttonclick() {
		resetb.click();
	}

}
