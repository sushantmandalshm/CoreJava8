package com.capgemini.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class FileProgram {

	public static void main(String[] args) throws FileNotFoundException {
		FileInputStream fis = new FileInputStream("source.txt");
		FileOutputStream fos = new FileOutputStream("target.txt");
		CopyDataThread cd= new CopyDataThread(fis,fos);
		Thread t= new Thread(cd);
		t.start();
	}

}
