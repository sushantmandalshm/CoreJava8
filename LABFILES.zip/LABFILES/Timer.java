package com.capgemini.io;

import java.time.LocalDateTime;

public class Timer implements Runnable {

	@Override
	public void run() 
	{
		while(true)
		{
			LocalDateTime d = LocalDateTime.now();
			int h = d.getHour();
			int m = d.getMinute();
			int s = d.getSecond();
			System.out.println(h + ":" + m + ":" + s);
			try
			{
				Thread.sleep(10000);
			}catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		
	}
	public static void main(String[] args) {
		Timer t = new Timer();
		Thread t1 = new Thread(t);
		t1.start();
	}

}
