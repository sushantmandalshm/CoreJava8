package com.capgemini.io;
import java.io.*;

public class CopyDataThread implements Runnable{
	private FileInputStream fis;
	private FileOutputStream fos;
	CopyDataThread(FileInputStream fis,FileOutputStream fos){
		this.fis=fis;
		this.fos=fos;
		
	}
	@Override
	public void run() {
		try{
		int ch,count=0;
		while((ch=fis.read()) != -1){
			if(count==10){
				System.out.println("10 charcters are copied");
				count=0;
				System.out.println("5 sec delay");
				Thread.sleep(5000);
			}
			fos.write(ch);
			count++;
		}
		System.out.println("Copying done");
		fis.close();
		fos.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
