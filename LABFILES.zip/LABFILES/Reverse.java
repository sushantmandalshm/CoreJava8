package com.capgemini.io;

import java.io.FileOutputStream;
import java.io.IOException;
public class Reverse {

	public static void main(String[] args) throws IOException 
	{
		FileOutputStream fos = new FileOutputStream("sample2.txt",false);
		StringBuffer s1 = new StringBuffer("Mango is good for health");
		StringBuffer s2 = new StringBuffer(" --esrever-- ");
		fos.write(s1.toString().getBytes());
		s2=s2.reverse();
		s2=s2.append(s1.reverse());
		fos.write(s2.toString().getBytes());
		fos.close();
	}
}
