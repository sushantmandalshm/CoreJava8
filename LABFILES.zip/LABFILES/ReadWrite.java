package com.capgemini.io;

import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
public class ReadWrite {

	public static void main(String[] args) throws IOException 
	{
		FileInputStream fis = new FileInputStream("sample.txt");
		FileOutputStream fos = new FileOutputStream("sample1.txt",false);
		int ch;
		while((ch=fis.read()) != -1)
		{
			fos.write((char)ch);
			System.out.print((char)ch);
		}
		fis.close();
		fos.close();
	}

}
