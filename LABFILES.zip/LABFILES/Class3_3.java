package com.capgemini.lab3;

import java.util.Date;

public class Class3_3 {

	void displaydate(Date d){
		
	}
	public static void main(String[] args) {
		

	}

}
