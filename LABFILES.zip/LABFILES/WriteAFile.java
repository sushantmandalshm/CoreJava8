package com.capgemini.io;

//import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
public class WriteAFile {

	public static void main(String[] args) throws IOException
	{
		// TODO Auto-generated method stub
		FileOutputStream fos = new FileOutputStream("sample.txt",false);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		//String s = "Hello Shm Good morning";
		String s = br.readLine();
		fos.write(s.getBytes());
		fos.close();
	}

}
